# bl-weaponrepair
 Simple weapon repair station for ox_inventory
 discord.gg/nYCvThHYyd